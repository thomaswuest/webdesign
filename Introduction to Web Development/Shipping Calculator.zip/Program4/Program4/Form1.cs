﻿// Program 4
// CIS 199-02
// Grading ID: B2560
// Due Date: 4/25/2017
// Project Description: The user inputs origin zip, destination zip, length, width, height,
//                      and weight. Package is then added to a listbox and able to be 
//                      selected. Details button click: displays all details inputted for specified
//                       price. Send to UofL button changes destination zip code to U of L zipcode and 
//                      updates price. Send from UofL button changes origin zip code to U of L zipcode and 
//                      updates price.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class program4 : Form
    {   // establishes a list to hold Package Objects
        // Will be held in line with strings outputted within the listbox
        private List<GroundPackage> packageList = new List<GroundPackage>();

        // Precondition: None
        // Posycondition: Form has been constructed and is ready to load
        public program4()
        {
            InitializeComponent();
        }

        //Precondition: None
        //Postcondition: Forms data will be collected, parsed, and the out parameters will hold data
        //               values entered by the user. If all values are valid, true will be returned.
        //               Otherwise the appropriate messagebox will return.
        
        private bool ValidatePackageData(out int originZip,out int destZip, out double length,  out double width, out double height, out double weight)
        {
            originZip = 0;
            destZip = 0;
            length = 0;
            width = 0;
            height = 0;
            weight = 0;


            bool isValid = false; // Are all data fields valid?

            if (int.TryParse(originTextBox.Text, out originZip))
            {
                if (int.TryParse(destTextBox.Text, out destZip))
                {
                    if (double.TryParse(lengthTextBox.Text, out length))
                    {
                        if (double.TryParse(widthTextBox.Text, out width))
                        {
                            if (double.TryParse(heightTextBox.Text, out height))
                            {
                                if (double.TryParse(weightTextBox.Text, out weight))
                                {
                                    isValid = true;
                                }
                                else
                                {
                                    MessageBox.Show("Please enter a correct weight value.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please enter a correct height value.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter a correct width value.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a correct length value.");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a correct destination zip code value.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a correct origin zip code value.");
            }

            return isValid;
        }

        // Precondition:  Add Package button is clicked
        // Postcondition: If form data are valid, a new Package will be added to the list,
        //                fields are cleared and focus reset.
        private void addPackageButton_Click(object sender, EventArgs e)
        {
            GroundPackage myPackage; // holds NEW package data
            int poriginZip; // entered origin zip code
            int pdestZip; // entered destination zip code
            double plength; // entered package length
            double pwidth; // entered package width
            double pheight; // entered package height
            double pweight; // entered package weight

            // get and validate the package data
            if (ValidatePackageData(out poriginZip, out pdestZip, out plength, out pwidth, out pheight, out pweight))
               {    // Will only create when all entered data is valid

                    // Create new GroundPackage object from the data entered
                    myPackage = new GroundPackage( poriginZip, pdestZip, plength, pwidth, pheight, pweight);

                    // Add the GroundPackage to the list
                    packageList.Add(myPackage);


                    packageOutputListbox.Items.Add(myPackage.CalcCost().ToString("c"));

                    // Cear the TextBox controls
                    originTextBox.Clear();
                    destTextBox.Clear();
                    lengthTextBox.Clear();
                    widthTextBox.Clear();
                    heightTextBox.Clear();
                    weightTextBox.Clear();

                    // Reset the focus
                    originTextBox.Focus();
                }
                                
        }

        //Precondition: Details Button is clicked and packageOutputListBox selection is made or changed 
        //Postcondition: Selected package price's details are displayed within a MessageBox
        private void detailButton_Click(object sender, EventArgs e)
        {
            int index; // Index of the selected items

            index = packageOutputListbox.SelectedIndex;

            if(index>=0) //Item was selected (otherwise -1)
            {
                // display the selected item's price
                // note: Used Ground Package ToString() to show all fields on a new line each time

                MessageBox.Show(packageList[index].ToString());
            }
            
        }
        // Precondition: send from UL Button is clicked
        // Postcondition: Selected package's price is updated within listbox based on DestZip change.
        private void sendtoULButton_Click(object sender, EventArgs e)
        {
            int index;
            index = packageOutputListbox.SelectedIndex;

            if (index >= 0)// Item was selected (otherwise -1)
            {   
                //Update Destination ZIp and update price within listbox
                packageList[index].DestinationZip = 40292;
                packageOutputListbox.Items[index] = packageList[index].CalcCost().ToString("c");
                MessageBox.Show("Destination Zip Code has been updated!");
            }
        }
        // Precondition:  send from UL Button is clicked
        // Postcondition: Selected package's price is updated within listbox based on OriginZip change.
        private void sendFromULButton_Click(object sender, EventArgs e)
        {
            int index;// index of selected items

            index = packageOutputListbox.SelectedIndex;

            if (index >= 0) //Item was selected (otherwise -1)
            {
                //Update Destination ZIp and update price within listbox
                packageList[index].OriginZip = 40292;
                packageOutputListbox.Items[index] = packageList[index].CalcCost().ToString("c");
                MessageBox.Show("Origin Zip Code has been updated!");
            }
        }
    }
                                }
                            
                        