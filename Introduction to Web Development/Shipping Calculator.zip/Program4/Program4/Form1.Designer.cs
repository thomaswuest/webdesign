﻿namespace Program4
{
    partial class program4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.packageGroupBox = new System.Windows.Forms.GroupBox();
            this.selectPackageGroupBox = new System.Windows.Forms.GroupBox();
            this.originZipLabel = new System.Windows.Forms.Label();
            this.destZipLabel = new System.Windows.Forms.Label();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.widthLabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.weightLabel = new System.Windows.Forms.Label();
            this.originTextBox = new System.Windows.Forms.TextBox();
            this.destTextBox = new System.Windows.Forms.TextBox();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.widthTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.addPackageButton = new System.Windows.Forms.Button();
            this.packageOutputListbox = new System.Windows.Forms.ListBox();
            this.detailButton = new System.Windows.Forms.Button();
            this.sendtoULButton = new System.Windows.Forms.Button();
            this.sendFromULButton = new System.Windows.Forms.Button();
            this.packageGroupBox.SuspendLayout();
            this.selectPackageGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // packageGroupBox
            // 
            this.packageGroupBox.Controls.Add(this.addPackageButton);
            this.packageGroupBox.Controls.Add(this.weightTextBox);
            this.packageGroupBox.Controls.Add(this.heightTextBox);
            this.packageGroupBox.Controls.Add(this.widthTextBox);
            this.packageGroupBox.Controls.Add(this.lengthTextBox);
            this.packageGroupBox.Controls.Add(this.destTextBox);
            this.packageGroupBox.Controls.Add(this.originTextBox);
            this.packageGroupBox.Controls.Add(this.weightLabel);
            this.packageGroupBox.Controls.Add(this.heightLabel);
            this.packageGroupBox.Controls.Add(this.widthLabel);
            this.packageGroupBox.Controls.Add(this.lengthLabel);
            this.packageGroupBox.Controls.Add(this.destZipLabel);
            this.packageGroupBox.Controls.Add(this.originZipLabel);
            this.packageGroupBox.Location = new System.Drawing.Point(56, 42);
            this.packageGroupBox.Name = "packageGroupBox";
            this.packageGroupBox.Size = new System.Drawing.Size(261, 266);
            this.packageGroupBox.TabIndex = 0;
            this.packageGroupBox.TabStop = false;
            this.packageGroupBox.Text = "Enter Package Data:";
            // 
            // selectPackageGroupBox
            // 
            this.selectPackageGroupBox.Controls.Add(this.packageOutputListbox);
            this.selectPackageGroupBox.Location = new System.Drawing.Point(390, 42);
            this.selectPackageGroupBox.Name = "selectPackageGroupBox";
            this.selectPackageGroupBox.Size = new System.Drawing.Size(251, 266);
            this.selectPackageGroupBox.TabIndex = 1;
            this.selectPackageGroupBox.TabStop = false;
            this.selectPackageGroupBox.Text = "Select a Package:";
            // 
            // originZipLabel
            // 
            this.originZipLabel.AutoSize = true;
            this.originZipLabel.Location = new System.Drawing.Point(6, 35);
            this.originZipLabel.Name = "originZipLabel";
            this.originZipLabel.Size = new System.Drawing.Size(74, 17);
            this.originZipLabel.TabIndex = 0;
            this.originZipLabel.Text = "Origin Zip:";
            // 
            // destZipLabel
            // 
            this.destZipLabel.AutoSize = true;
            this.destZipLabel.Location = new System.Drawing.Point(6, 64);
            this.destZipLabel.Name = "destZipLabel";
            this.destZipLabel.Size = new System.Drawing.Size(107, 17);
            this.destZipLabel.TabIndex = 1;
            this.destZipLabel.Text = "Destination Zip:";
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(6, 93);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(56, 17);
            this.lengthLabel.TabIndex = 2;
            this.lengthLabel.Text = "Length:";
            // 
            // widthLabel
            // 
            this.widthLabel.AutoSize = true;
            this.widthLabel.Location = new System.Drawing.Point(6, 122);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(48, 17);
            this.widthLabel.TabIndex = 3;
            this.widthLabel.Text = "Width:";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Location = new System.Drawing.Point(6, 150);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(53, 17);
            this.heightLabel.TabIndex = 4;
            this.heightLabel.Text = "Height:";
            // 
            // weightLabel
            // 
            this.weightLabel.AutoSize = true;
            this.weightLabel.Location = new System.Drawing.Point(6, 178);
            this.weightLabel.Name = "weightLabel";
            this.weightLabel.Size = new System.Drawing.Size(56, 17);
            this.weightLabel.TabIndex = 5;
            this.weightLabel.Text = "Weight:";
            // 
            // originTextBox
            // 
            this.originTextBox.Location = new System.Drawing.Point(120, 32);
            this.originTextBox.Name = "originTextBox";
            this.originTextBox.Size = new System.Drawing.Size(100, 22);
            this.originTextBox.TabIndex = 6;
            // 
            // destTextBox
            // 
            this.destTextBox.Location = new System.Drawing.Point(120, 61);
            this.destTextBox.Name = "destTextBox";
            this.destTextBox.Size = new System.Drawing.Size(100, 22);
            this.destTextBox.TabIndex = 7;
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Location = new System.Drawing.Point(120, 90);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.Size = new System.Drawing.Size(100, 22);
            this.lengthTextBox.TabIndex = 8;
            // 
            // widthTextBox
            // 
            this.widthTextBox.Location = new System.Drawing.Point(120, 119);
            this.widthTextBox.Name = "widthTextBox";
            this.widthTextBox.Size = new System.Drawing.Size(100, 22);
            this.widthTextBox.TabIndex = 9;
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(120, 147);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(100, 22);
            this.heightTextBox.TabIndex = 10;
            // 
            // weightTextBox
            // 
            this.weightTextBox.Location = new System.Drawing.Point(120, 175);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(100, 22);
            this.weightTextBox.TabIndex = 11;
            // 
            // addPackageButton
            // 
            this.addPackageButton.Location = new System.Drawing.Point(70, 216);
            this.addPackageButton.Name = "addPackageButton";
            this.addPackageButton.Size = new System.Drawing.Size(118, 37);
            this.addPackageButton.TabIndex = 12;
            this.addPackageButton.Text = "Add Package";
            this.addPackageButton.UseVisualStyleBackColor = true;
            this.addPackageButton.Click += new System.EventHandler(this.addPackageButton_Click);
            // 
            // packageOutputListbox
            // 
            this.packageOutputListbox.FormattingEnabled = true;
            this.packageOutputListbox.ItemHeight = 16;
            this.packageOutputListbox.Location = new System.Drawing.Point(21, 32);
            this.packageOutputListbox.Name = "packageOutputListbox";
            this.packageOutputListbox.Size = new System.Drawing.Size(209, 212);
            this.packageOutputListbox.TabIndex = 0;
            // 
            // detailButton
            // 
            this.detailButton.Location = new System.Drawing.Point(647, 71);
            this.detailButton.Name = "detailButton";
            this.detailButton.Size = new System.Drawing.Size(117, 39);
            this.detailButton.TabIndex = 2;
            this.detailButton.Text = "Details";
            this.detailButton.UseVisualStyleBackColor = true;
            this.detailButton.Click += new System.EventHandler(this.detailButton_Click);
            // 
            // sendtoULButton
            // 
            this.sendtoULButton.Location = new System.Drawing.Point(648, 116);
            this.sendtoULButton.Name = "sendtoULButton";
            this.sendtoULButton.Size = new System.Drawing.Size(116, 38);
            this.sendtoULButton.TabIndex = 3;
            this.sendtoULButton.Text = "Send to UofL";
            this.sendtoULButton.UseVisualStyleBackColor = true;
            this.sendtoULButton.Click += new System.EventHandler(this.sendtoULButton_Click);
            // 
            // sendFromULButton
            // 
            this.sendFromULButton.Location = new System.Drawing.Point(648, 164);
            this.sendFromULButton.Name = "sendFromULButton";
            this.sendFromULButton.Size = new System.Drawing.Size(116, 45);
            this.sendFromULButton.TabIndex = 4;
            this.sendFromULButton.Text = "Send from UofL";
            this.sendFromULButton.UseVisualStyleBackColor = true;
            this.sendFromULButton.Click += new System.EventHandler(this.sendFromULButton_Click);
            // 
            // program4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 342);
            this.Controls.Add(this.sendFromULButton);
            this.Controls.Add(this.sendtoULButton);
            this.Controls.Add(this.detailButton);
            this.Controls.Add(this.selectPackageGroupBox);
            this.Controls.Add(this.packageGroupBox);
            this.Name = "program4";
            this.Text = "Program 4";
            this.packageGroupBox.ResumeLayout(false);
            this.packageGroupBox.PerformLayout();
            this.selectPackageGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox packageGroupBox;
        private System.Windows.Forms.Label weightLabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label destZipLabel;
        private System.Windows.Forms.Label originZipLabel;
        private System.Windows.Forms.GroupBox selectPackageGroupBox;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.TextBox widthTextBox;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.TextBox destTextBox;
        private System.Windows.Forms.TextBox originTextBox;
        private System.Windows.Forms.Button addPackageButton;
        private System.Windows.Forms.ListBox packageOutputListbox;
        private System.Windows.Forms.Button detailButton;
        private System.Windows.Forms.Button sendtoULButton;
        private System.Windows.Forms.Button sendFromULButton;
    }
}

