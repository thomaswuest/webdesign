﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class GroundPackage
    {   // Backing Fields
        private int _originzip; // Package Origin Zip
        private int _destzip; // Package Destination Zip
        private double _length; // Package Length
        private double _width; // Package Width
        private double _height; // Package Height
        private double _weight; // Package Weight


        // Constructor
        // Precondition:  theBrand, theModel are not empty/whitespace
        //                thePrice >= 0
        // Postcondition: A CellPhone has been constructed with specified properties
        public GroundPackage( int theOriginZip, int theDestinationZip, double theLength, double theWidth, double theHeight, double theWeight)
        {
            OriginZip = theOriginZip;
            DestinationZip = theDestinationZip;
            Length = theLength;
            Width = theWidth;
            Height = theHeight;
            Weight = theWeight;

        }
        //OriginZip property
        public int OriginZip
        {   
            // Precondition:  None
            // Postcondition: The originzip has been returned
            get { return _originzip; }

            // Precondition:  value > 00000 && value < 99999
            // Postcondition: The originzip has been set to the specified  value
            set
            {
                if (value > 00000 && value < 99999)
                    _originzip = value;
                else
                    _originzip = 40202;
            }
        }
        // DestinationZip Property
        public int DestinationZip
        {
            // Precondition:  None
            // Postcondition: The destzip has been returned
            get { return _destzip; }

            // Precondition:  value > 00000 && value < 99999)
            // Postcondition: The destzip has been set to the specified value
            set
            {
                if (value > 00000 && value < 99999)
                    _destzip = value;
                else
                    _destzip = 90210;
            }
        }
        // Length Property
        public double Length
        {
            // Precondition:  None
            // Postcondition: The length has been returned
            get { return _length; }

            // Precondition:  value > 0
            // Postcondition: The length has been set to the specified (trimmed)
            set
            {
                if (value > 0) //valid
                    _length = value;
                else
                    _length = 1.0;
            }
        }
        // Width Property
        public double Width
        {
            // Precondition:  None
            // Postcondition: The width has been returned
            get { return _width; }


            // Precondition:  value > 0
            // Postcondition: The width has been set to the specified value
            set
            {
                if (value > 0) //valid
                    _width = value;
                else
                    _width = 1.0;
            }
        }
        //Height Property
        public double Height
        {
            // Precondition:  None
            // Postcondition: The height has been returned
            get { return _height; }


            // Precondition:  value > 0
            // Postcondition: The Height has been set to the specified value
            set
            {
                if (value > 0) //valid
                    _height = value;
                else
                    _height = 1.0;
            }
        }
        //Weight Property
        public double Weight
        {
            // Precondition:  None
            // Postcondition: The weight has been returned
            get { return _weight; }


            // Precondition:  value > 0
            // Postcondition: The weight has been set to the specified value
            set
            {
                if (value > 0) //valid
                    _weight = value;
                else
                    _weight = 1.0;
            }
        }
        // Precondition:  None
        // Postcondition: Calculation of ZoneDistance Returned
        public int ZoneDistance
        {
            get
            {
                int zoneDistance;
                zoneDistance = Math.Abs((_originzip / 10000) - (_destzip / 10000));
                return zoneDistance;
            }
        }
        // Precondition: None
        // Postcondition: COst of shipping the Ground Package is returned
        public double CalcCost()
        {
            return .2 * (Length + Width + Height) + .5 * (ZoneDistance + 1) * (Weight);
        }
        // ToString method
        // Precondition:  None
        // Postcondition: A formatted string representing the specific GroundPackage is returned
        public override string ToString()
        {
            return "Origin Zip Code:" +" "+ OriginZip.ToString("d5") + System.Environment.NewLine +
                "Destination Zip Code:"+ " " + DestinationZip.ToString("d5") + System.Environment.NewLine +
                "Length:"+ " "+ + Length + System.Environment.NewLine +
                "Width:" + " "+ Width + System.Environment.NewLine +
                "Height:"+ " "+ Height + System.Environment.NewLine +
                "Weight:" + " "+ Weight + System.Environment.NewLine;


        }
    }
}
