﻿// Program 2
// CIS 199-02
// Due: 3/7/2017
// By: B2560

// This application calculates the earliest registration date
// and time for an undergraduate student given their class standing
// and last name.
// Decisions based on UofL Fall/Summer 2017 Priority Registration Schedule

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Pre Condition: lastNameLetterCH >= 'A' && lastNameLetterCH <= 'Z'
        // Post Condirion: If desired value entered is within precondition range and desired
        // radiobutton is selected; the character will be extracted and the correct registration time will display.
        // Find and display earliest registration time
        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            char[] fSCharArray = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' }; // holds char values for freshman/sophomore
            string[] fSRegTimes = { "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM", "2:00 PM","4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM", "2:00 PM," }; // holds time strings for freshman/sophomore
            char[] jSCharArray = { 'A', 'E', 'J', 'P', 'T' };// holds char values for junior/senior
            string[] jSRegTimes = { "11:30 AM", "2:00 PM", "4:00 PM", "8:30 AM", "10:00 AM" };// holds time strings for junior/senior

            const string DAY1 = "March 29";  // 1st day of registration
            const string DAY2 = "March 30";  // 2nd day of registration
            const string DAY3 = "March 31";  // 3rd day of registration
            const string DAY4 = "April 3";   // 4th day of registration
            const string DAY5 = "April 4";   // 5th day of registration
            const string DAY6 = "April 5";   // 6th day of registration

            string lastNameStr;       // Entered last name
            char lastNameLetterCh;    // First letter of last name, as char
            string dateStr = "Error"; // Holds date of registration
            string timeStr = "Error"; // Holds time of registration
            bool isUpperClass;        // Upperclass or not?
            bool found = false;
            int index1 = fSCharArray.Length - 1; // establishment of index for freshman/sophomore
            int index2 = jSCharArray.Length - 1; // establishment of index for junior/senior

            lastNameStr = lastNameTxt.Text;
            if (lastNameStr.Length > 0) // Empty string?
            {
                lastNameLetterCh = lastNameStr[0];   // First char of last name
                lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                {
                    isUpperClass = (seniorRBtn.Checked || juniorRBtn.Checked);

                    // Juniors and Seniors share same schedule but different days
                    if (isUpperClass)
                    {
                        if (seniorRBtn.Checked)
                            dateStr = DAY1;
                        else // Must be juniors
                            dateStr = DAY2;
                        while (index2 >= 0 && !found)// while loop to find correct time when char value entered
                        {
                            if (lastNameLetterCh >= jSCharArray[index2])
                                found = true;
                            else
                                --index2;
                        }
                        if (found)
                            timeStr = jSRegTimes[index2];// assigns time using parallel arrays when index position is found within array
                    }
                    // Sophomores and Freshmen
                    else // Must be soph/fresh
                    {
                        if (sophomoreRBtn.Checked)
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY4;
                            else // All other letters on previous day
                                dateStr = DAY3;

                            while (index1 >= 0 && !found)// while loop to find correct time when char value entered
                            {
                                if (lastNameLetterCh >= fSCharArray[index1])
                                    found = true;
                                else
                                    --index1;
                            }
                            if (found)
                                timeStr = fSRegTimes[index1]; // assigns time using parallel arrays when index position is found within array
                        }
                        else // must be freshman
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY6;
                            else // All other letters on previous day
                                dateStr = DAY5;
                            while (index1 >= 0 && !found) // while loop to find correct time when char value entered
                            {
                            if (lastNameLetterCh >= fSCharArray[index1])
                                found = true;
                            else
                                --index1;
                            }
                            if (found)
                               timeStr = fSRegTimes[index1]; // assigns time using parallel arrays when index position is found within array
                        }
                    }
                     // Output results
                    dateTimeLbl.Text = dateStr + " at " + timeStr; // concatenation of date and time and output to label
                }
                    else // First char not a letter
                    MessageBox.Show("Make sure last name starts with a letter"); // error when a non letter value is entered for the first charachter
              }
                else // Empty textbox
                MessageBox.Show("Enter a last name!");  // output when textbox is empty
           }
        }
    }

