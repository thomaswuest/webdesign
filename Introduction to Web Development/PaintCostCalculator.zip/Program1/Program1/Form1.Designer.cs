﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.squareFeetLabel = new System.Windows.Forms.Label();
            this.coatsLabel = new System.Windows.Forms.Label();
            this.ppgLabel = new System.Windows.Forms.Label();
            this.squareFeetTextBox = new System.Windows.Forms.TextBox();
            this.coatsTextBox = new System.Windows.Forms.TextBox();
            this.ppgTextBox = new System.Windows.Forms.TextBox();
            this.squareFeetOutputLabel = new System.Windows.Forms.Label();
            this.gallonOutputLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.areaOutputLabel = new System.Windows.Forms.Label();
            this.paintAmountOutputLabel = new System.Windows.Forms.Label();
            this.hoursOutputLabel = new System.Windows.Forms.Label();
            this.paintCostOutputLabel = new System.Windows.Forms.Label();
            this.laborCostOutputLabel = new System.Windows.Forms.Label();
            this.totalCostOutputLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // squareFeetLabel
            // 
            this.squareFeetLabel.AutoSize = true;
            this.squareFeetLabel.Location = new System.Drawing.Point(25, 40);
            this.squareFeetLabel.Name = "squareFeetLabel";
            this.squareFeetLabel.Size = new System.Drawing.Size(285, 17);
            this.squareFeetLabel.TabIndex = 0;
            this.squareFeetLabel.Text = "The square feet of wall space to be painted:";
            // 
            // coatsLabel
            // 
            this.coatsLabel.AutoSize = true;
            this.coatsLabel.Location = new System.Drawing.Point(65, 65);
            this.coatsLabel.Name = "coatsLabel";
            this.coatsLabel.Size = new System.Drawing.Size(245, 17);
            this.coatsLabel.TabIndex = 1;
            this.coatsLabel.Text = "The number of coats of paint desired:";
            // 
            // ppgLabel
            // 
            this.ppgLabel.AutoSize = true;
            this.ppgLabel.Location = new System.Drawing.Point(96, 93);
            this.ppgLabel.Name = "ppgLabel";
            this.ppgLabel.Size = new System.Drawing.Size(214, 17);
            this.ppgLabel.TabIndex = 2;
            this.ppgLabel.Text = "The price of the paint per gallon:";
            // 
            // squareFeetTextBox
            // 
            this.squareFeetTextBox.Location = new System.Drawing.Point(316, 37);
            this.squareFeetTextBox.Name = "squareFeetTextBox";
            this.squareFeetTextBox.Size = new System.Drawing.Size(100, 22);
            this.squareFeetTextBox.TabIndex = 3;
            this.squareFeetTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // coatsTextBox
            // 
            this.coatsTextBox.Location = new System.Drawing.Point(316, 62);
            this.coatsTextBox.Name = "coatsTextBox";
            this.coatsTextBox.Size = new System.Drawing.Size(100, 22);
            this.coatsTextBox.TabIndex = 4;
            this.coatsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ppgTextBox
            // 
            this.ppgTextBox.Location = new System.Drawing.Point(316, 90);
            this.ppgTextBox.Name = "ppgTextBox";
            this.ppgTextBox.Size = new System.Drawing.Size(100, 22);
            this.ppgTextBox.TabIndex = 5;
            this.ppgTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // squareFeetOutputLabel
            // 
            this.squareFeetOutputLabel.AutoSize = true;
            this.squareFeetOutputLabel.Location = new System.Drawing.Point(74, 148);
            this.squareFeetOutputLabel.Name = "squareFeetOutputLabel";
            this.squareFeetOutputLabel.Size = new System.Drawing.Size(236, 17);
            this.squareFeetOutputLabel.TabIndex = 6;
            this.squareFeetOutputLabel.Text = "Total number of area to be covered:";
            // 
            // gallonOutputLabel
            // 
            this.gallonOutputLabel.AutoSize = true;
            this.gallonOutputLabel.Location = new System.Drawing.Point(88, 177);
            this.gallonOutputLabel.Name = "gallonOutputLabel";
            this.gallonOutputLabel.Size = new System.Drawing.Size(222, 17);
            this.gallonOutputLabel.TabIndex = 7;
            this.gallonOutputLabel.Text = "Amount of paint needed (gallons):";
            // 
            // hoursLabel
            // 
            this.hoursLabel.AutoSize = true;
            this.hoursLabel.Location = new System.Drawing.Point(124, 204);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(186, 17);
            this.hoursLabel.TabIndex = 8;
            this.hoursLabel.Text = "The hours of labor required:";
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.AutoSize = true;
            this.paintCostLabel.Location = new System.Drawing.Point(168, 231);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(142, 17);
            this.paintCostLabel.TabIndex = 9;
            this.paintCostLabel.Text = "The cost of the paint:";
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.AutoSize = true;
            this.laborCostLabel.Location = new System.Drawing.Point(167, 259);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(143, 17);
            this.laborCostLabel.TabIndex = 10;
            this.laborCostLabel.Text = "The cost of the labor:";
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Location = new System.Drawing.Point(114, 288);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(196, 17);
            this.totalCostLabel.TabIndex = 11;
            this.totalCostLabel.Text = "The total cost of the paint job:";
            // 
            // areaOutputLabel
            // 
            this.areaOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.areaOutputLabel.Location = new System.Drawing.Point(316, 147);
            this.areaOutputLabel.Name = "areaOutputLabel";
            this.areaOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.areaOutputLabel.TabIndex = 12;
            this.areaOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paintAmountOutputLabel
            // 
            this.paintAmountOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintAmountOutputLabel.Location = new System.Drawing.Point(316, 176);
            this.paintAmountOutputLabel.Name = "paintAmountOutputLabel";
            this.paintAmountOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.paintAmountOutputLabel.TabIndex = 13;
            this.paintAmountOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hoursOutputLabel
            // 
            this.hoursOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursOutputLabel.Location = new System.Drawing.Point(316, 203);
            this.hoursOutputLabel.Name = "hoursOutputLabel";
            this.hoursOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.hoursOutputLabel.TabIndex = 14;
            this.hoursOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paintCostOutputLabel
            // 
            this.paintCostOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintCostOutputLabel.Location = new System.Drawing.Point(316, 230);
            this.paintCostOutputLabel.Name = "paintCostOutputLabel";
            this.paintCostOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.paintCostOutputLabel.TabIndex = 15;
            this.paintCostOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // laborCostOutputLabel
            // 
            this.laborCostOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborCostOutputLabel.Location = new System.Drawing.Point(316, 258);
            this.laborCostOutputLabel.Name = "laborCostOutputLabel";
            this.laborCostOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.laborCostOutputLabel.TabIndex = 16;
            this.laborCostOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalCostOutputLabel
            // 
            this.totalCostOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOutputLabel.Location = new System.Drawing.Point(316, 287);
            this.totalCostOutputLabel.Name = "totalCostOutputLabel";
            this.totalCostOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.totalCostOutputLabel.TabIndex = 17;
            this.totalCostOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(170, 350);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(162, 38);
            this.calculateButton.TabIndex = 18;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Program1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 425);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalCostOutputLabel);
            this.Controls.Add(this.laborCostOutputLabel);
            this.Controls.Add(this.paintCostOutputLabel);
            this.Controls.Add(this.hoursOutputLabel);
            this.Controls.Add(this.paintAmountOutputLabel);
            this.Controls.Add(this.areaOutputLabel);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.gallonOutputLabel);
            this.Controls.Add(this.squareFeetOutputLabel);
            this.Controls.Add(this.ppgTextBox);
            this.Controls.Add(this.coatsTextBox);
            this.Controls.Add(this.squareFeetTextBox);
            this.Controls.Add(this.ppgLabel);
            this.Controls.Add(this.coatsLabel);
            this.Controls.Add(this.squareFeetLabel);
            this.Name = "Program1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label squareFeetLabel;
        private System.Windows.Forms.Label coatsLabel;
        private System.Windows.Forms.Label ppgLabel;
        private System.Windows.Forms.TextBox squareFeetTextBox;
        private System.Windows.Forms.TextBox coatsTextBox;
        private System.Windows.Forms.TextBox ppgTextBox;
        private System.Windows.Forms.Label squareFeetOutputLabel;
        private System.Windows.Forms.Label gallonOutputLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label areaOutputLabel;
        private System.Windows.Forms.Label paintAmountOutputLabel;
        private System.Windows.Forms.Label hoursOutputLabel;
        private System.Windows.Forms.Label paintCostOutputLabel;
        private System.Windows.Forms.Label laborCostOutputLabel;
        private System.Windows.Forms.Label totalCostOutputLabel;
        private System.Windows.Forms.Button calculateButton;
    }
}

