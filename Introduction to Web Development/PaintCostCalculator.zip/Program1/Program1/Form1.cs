﻿// Program 1
// Due Date 2/14/2017
// CIS 199-02
// Grading ID: B2560

/* This program is designed allow a user to estimate the cost of an
   area that they desire to paint. The user will input the square footage,
   the number of coats for said area, and the price per gallon of paint they
   will be using. The program will then output the total square feet, the number
   of gallons to buy, the total number of hours for completion, the paint cost, the 
   labor cost, and the total cost for the project to be completed. This can be useful 
   for all types of users when they are deciding how much painting a certain area 
   might cost.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {// Constants
        // Can be used throughout the entire program

        private const float SQUARE_FEET = 330.0f ; // Named constant of square footage per gallon of paint - set forth by the painting company.
        private const int HOURS = 6; // Named constant of labor per 330 sq. feet - set forth by the painting company.
        private const float HOURLY_PAY = 10.50f; // Named constant of hourly pay for employees working for the painting company.

        public Program1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            float SQUARE_FOOT; // variable for text input of desired square footage.
            int COATS; // variable for text input of desired number of coats.
            float PPG; // variable for text input of desired paint price .
            float T_SQUARE_FEET; // variable for calculating total number of square feet based on amount of coats.
            double GALLONS_REQUIRED; // variable for calculating total number of gallons required
            float LABOR_REQUIRED; // variable for calculating total number of labor hours required
            double PAINT_COST; // variable for calculating total paint cost
            double LABOR_COST; // variable for calculating total labor cost
            double TOTAL_COST; // variable for calculating total job cost


            SQUARE_FOOT = float.Parse(squareFeetTextBox.Text); // converts text input into a specified format to use for calculations
            COATS = int.Parse(coatsTextBox.Text); // converts text input into a specified format to use for calculations
            PPG = float.Parse(ppgTextBox.Text); // converts text input into a specified format to use for calculations

            T_SQUARE_FEET = SQUARE_FOOT * COATS; // Calculation for total number of Square Feet
            areaOutputLabel.Text = T_SQUARE_FEET.ToString("f1"); // Outputs total Square Feet to output label

            GALLONS_REQUIRED = T_SQUARE_FEET / SQUARE_FEET; // Calculation for total gallons required of paint
            GALLONS_REQUIRED = Math.Ceiling(GALLONS_REQUIRED); // math.Ceiling rounds up to the nearest whole integer, applicable for paint coverage
            paintAmountOutputLabel.Text = GALLONS_REQUIRED.ToString("f0");// Outputs total Square Feet to output label

            LABOR_REQUIRED = T_SQUARE_FEET / SQUARE_FEET * HOURS;// Calculation for total number of labor hours
            hoursOutputLabel.Text = LABOR_REQUIRED.ToString("f1");// Outputs total labor hours to output label

            PAINT_COST = GALLONS_REQUIRED * PPG; // Calculation for total paint cost
            paintCostOutputLabel.Text = PAINT_COST.ToString("c");// Outputs total paint cost to output label

            LABOR_COST = LABOR_REQUIRED * HOURLY_PAY; // Calculation for total Labor Cost
            laborCostOutputLabel.Text = LABOR_COST.ToString("c");// Outputs total Labor Cost to output label

            TOTAL_COST = PAINT_COST + LABOR_COST; // Calculation for total cost of painting project
            totalCostOutputLabel.Text = TOTAL_COST.ToString("c");// Outputs total cost to output label













        }
    }
}
