﻿// B2560
// Program 2
// Due Date: 03/07/2017
// CIS 199-02
/* Description: This program allows a specific student to enter their Last Name
   and find their earliest class registration date and time. The user must enetr their
   last name and current class standing for the program to run. The desired output is then
   displayed in an output label for date and time.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e) // submit button click event handler
        {
            char letter; // defined local variable "letter" stored as char data type
            letter = nameTextBox.Text[0]; // extracts input from textbox and stores first character
            letter = char.ToUpper(letter); // makes first character always an uppercase character

            if (seniorRB.Checked || juniorRB.Checked) // if Senior radio button or Junior radio button is checked
            {
                if (seniorRB.Checked) // if Senior radio button is checked
                {
                    dayOutputLabel.Text = "March 29th, 2017"; // display senior registration date
                }
                else if (juniorRB.Checked) // if Junior radio button is checked
                {
                    dayOutputLabel.Text = "March 30th, 2017"; // display junior registration date
                }
                // Logical test expressions for character extracted
                // Junior/Senior follow same registration pattern
                {
                    if (letter <= 'D') // if first character is less than or equal to 'D'
                    {
                        timeOutputLabel.Text = "11:30 AM"; // Displays registration time for A-D
                    }
                    else if (letter <= 'I') // if first character is less than or equal to 'I'
                    {
                        timeOutputLabel.Text = "2:00 PM"; // Displays registration time for E-I
                    }
                    else if (letter <= 'O') // if first character is less than or equal to 'O'
                    {
                        timeOutputLabel.Text = "4:00 PM"; // Displays registration time for J-O
                    }
                    else if (letter <= 'S') // if first character is less than or equal to 'S'
                    {
                        timeOutputLabel.Text = "8:30 AM"; // Displays registration time for P-S
                    }
                    else if (letter <= 'Z') // if first character is less than or equal to 'Z'
                    {
                        timeOutputLabel.Text = "10:00 AM"; // Displays registration time for T-Z
                    }
                }
            }
            else if (freshmanRB.Checked || sophomoreRB.Checked) // if sophomore radio button or freshman radio button is checked
            {
                if (sophomoreRB.Checked) // if sophomore radio button is checked
                { // Two days of registration
                    if (letter <= 'B')
                        if (letter <= 'B')
                        {
                            dayOutputLabel.Text = "March 31st, 2017"; // Displays First registration day
                        }
                        else if (letter <= 'O') // if Last Name is less than or equal to 'O'
                        {
                            dayOutputLabel.Text = "April 3rd, 2017"; // Displays Second registration day
                        }
                        else if (letter <= 'Z') // // if Last Name is less than or equal to 'Z'
                        {
                            dayOutputLabel.Text = "March 31st, 2017"; // Displays First registration day
                        }
                }
                else if (freshmanRB.Checked) // if freshman radio button is checked
                {// Two days of registration
                    if (letter <= 'B') // if Last Name is less than or equal to 'B'
                    {
                        dayOutputLabel.Text = "April 4th, 2017"; // Displays First registration day
                    }
                    else if (letter <= 'O') // if Last Name is less than or equal to 'O'
                    {
                        dayOutputLabel.Text = "April 5th, 2017"; // Displays Second registration day
                    }
                    else if (letter <= 'Z') // // if Last Name is less than or equal to 'Z'
                    {
                        dayOutputLabel.Text = "April 4th, 2017"; // Displays First registration day
                    }
                }

                if (letter <= 'B') // if first character is less than or equal to 'B'
                {
                    timeOutputLabel.Text = "4:00 PM"; // Displays registration time for A-B
                }
                else if (letter <= 'D') // if first character is less than or equal to 'D'
                {
                    timeOutputLabel.Text = "8:30 AM"; // Displays registration time for C-D
                }
                else if (letter <= 'F') // if first character is less than or equal to 'F'
                {
                    timeOutputLabel.Text = "10:00 AM"; // Displays registration time for E-F
                }
                else if (letter <= 'I') // if first character is less than or equal to 'I'
                {
                    timeOutputLabel.Text = "11:30 AM"; // Displays registration time for G-I
                }
                else if (letter <= 'L') // if first character is less than or equal to 'L'
                {
                    timeOutputLabel.Text = "2:00 PM"; // Displays registration time for J-L
                }
                else if (letter <= 'O') // if first character is less than or equal to 'O'
                {
                    timeOutputLabel.Text = "4:00 PM"; // Displays registration time for M-O
                }
                else if (letter <= 'Q') // if first character is less than or equal to 'Q'
                {
                    timeOutputLabel.Text = "8:30 AM"; // Displays registration time for P-Q
                }
                else if (letter <= 'S') // if first character is less than or equal to 'S'
                {
                    timeOutputLabel.Text = "10:00 AM"; // Displays registration time for R-S
                }
                else if (letter <= 'V') // if first character is less than or equal to 'V'
                {
                    timeOutputLabel.Text = "11:30 AM"; // Displays registration time for T-V
                }
                else if (letter <= 'Z') // if first character is less than or equal to 'Z'
                {
                    timeOutputLabel.Text = "2:00 PM"; // Displays registration time for W-Z
                }
            }
            else   
            { MessageBox.Show("Please select a class standing RadioButton.");} // outputs a messagebox if no class standing is selected
        }
    }
}
           


    

