﻿namespace Program_2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lastnameLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.classGB = new System.Windows.Forms.GroupBox();
            this.seniorRB = new System.Windows.Forms.RadioButton();
            this.juniorRB = new System.Windows.Forms.RadioButton();
            this.sophomoreRB = new System.Windows.Forms.RadioButton();
            this.freshmanRB = new System.Windows.Forms.RadioButton();
            this.submitButton = new System.Windows.Forms.Button();
            this.dayOutputLabel = new System.Windows.Forms.Label();
            this.timeOutputLabel = new System.Windows.Forms.Label();
            this.dayLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.classGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // lastnameLabel
            // 
            this.lastnameLabel.AutoSize = true;
            this.lastnameLabel.Location = new System.Drawing.Point(65, 40);
            this.lastnameLabel.Name = "lastnameLabel";
            this.lastnameLabel.Size = new System.Drawing.Size(143, 17);
            this.lastnameLabel.TabIndex = 0;
            this.lastnameLabel.Text = "Enter your last name:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(232, 37);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 22);
            this.nameTextBox.TabIndex = 1;
            // 
            // classGB
            // 
            this.classGB.Controls.Add(this.seniorRB);
            this.classGB.Controls.Add(this.juniorRB);
            this.classGB.Controls.Add(this.sophomoreRB);
            this.classGB.Controls.Add(this.freshmanRB);
            this.classGB.Location = new System.Drawing.Point(68, 111);
            this.classGB.Name = "classGB";
            this.classGB.Size = new System.Drawing.Size(264, 147);
            this.classGB.TabIndex = 2;
            this.classGB.TabStop = false;
            this.classGB.Text = "Select your current class standing:";
            // 
            // seniorRB
            // 
            this.seniorRB.AutoSize = true;
            this.seniorRB.Location = new System.Drawing.Point(57, 122);
            this.seniorRB.Name = "seniorRB";
            this.seniorRB.Size = new System.Drawing.Size(70, 21);
            this.seniorRB.TabIndex = 3;
            this.seniorRB.TabStop = true;
            this.seniorRB.Text = "Senior";
            this.seniorRB.UseVisualStyleBackColor = true;
            // 
            // juniorRB
            // 
            this.juniorRB.AutoSize = true;
            this.juniorRB.Location = new System.Drawing.Point(57, 95);
            this.juniorRB.Name = "juniorRB";
            this.juniorRB.Size = new System.Drawing.Size(68, 21);
            this.juniorRB.TabIndex = 2;
            this.juniorRB.TabStop = true;
            this.juniorRB.Text = "Junior";
            this.juniorRB.UseVisualStyleBackColor = true;
            // 
            // sophomoreRB
            // 
            this.sophomoreRB.AutoSize = true;
            this.sophomoreRB.Location = new System.Drawing.Point(57, 68);
            this.sophomoreRB.Name = "sophomoreRB";
            this.sophomoreRB.Size = new System.Drawing.Size(102, 21);
            this.sophomoreRB.TabIndex = 1;
            this.sophomoreRB.TabStop = true;
            this.sophomoreRB.Text = "Sophomore";
            this.sophomoreRB.UseVisualStyleBackColor = true;
            // 
            // freshmanRB
            // 
            this.freshmanRB.AutoSize = true;
            this.freshmanRB.Location = new System.Drawing.Point(57, 41);
            this.freshmanRB.Name = "freshmanRB";
            this.freshmanRB.Size = new System.Drawing.Size(92, 21);
            this.freshmanRB.TabIndex = 0;
            this.freshmanRB.TabStop = true;
            this.freshmanRB.Text = "Freshman";
            this.freshmanRB.UseVisualStyleBackColor = true;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(160, 293);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(85, 31);
            this.submitButton.TabIndex = 3;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // dayOutputLabel
            // 
            this.dayOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dayOutputLabel.Location = new System.Drawing.Point(170, 340);
            this.dayOutputLabel.Name = "dayOutputLabel";
            this.dayOutputLabel.Size = new System.Drawing.Size(194, 23);
            this.dayOutputLabel.TabIndex = 4;
            this.dayOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timeOutputLabel
            // 
            this.timeOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeOutputLabel.Location = new System.Drawing.Point(171, 382);
            this.timeOutputLabel.Name = "timeOutputLabel";
            this.timeOutputLabel.Size = new System.Drawing.Size(194, 23);
            this.timeOutputLabel.TabIndex = 5;
            this.timeOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dayLabel
            // 
            this.dayLabel.AutoSize = true;
            this.dayLabel.Location = new System.Drawing.Point(42, 343);
            this.dayLabel.Name = "dayLabel";
            this.dayLabel.Size = new System.Drawing.Size(122, 17);
            this.dayLabel.TabIndex = 6;
            this.dayLabel.Text = "Registration Date:";
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Location = new System.Drawing.Point(42, 385);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(123, 17);
            this.timeLabel.TabIndex = 7;
            this.timeLabel.Text = "Registration Time:";
            // 
            // Program2
            // 
            this.AcceptButton = this.submitButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 459);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.dayLabel);
            this.Controls.Add(this.timeOutputLabel);
            this.Controls.Add(this.dayOutputLabel);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.classGB);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.lastnameLabel);
            this.Name = "Program2";
            this.Text = "Form1";
            this.classGB.ResumeLayout(false);
            this.classGB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lastnameLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.GroupBox classGB;
        private System.Windows.Forms.RadioButton seniorRB;
        private System.Windows.Forms.RadioButton juniorRB;
        private System.Windows.Forms.RadioButton sophomoreRB;
        private System.Windows.Forms.RadioButton freshmanRB;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label dayOutputLabel;
        private System.Windows.Forms.Label timeOutputLabel;
        private System.Windows.Forms.Label dayLabel;
        private System.Windows.Forms.Label timeLabel;
    }
}

