﻿// Grading ID:D7370
// CIS 200-76
// October 23,2017
// Program2
// In this specific class we create the functionality for creating and display all addresses
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp

{
    public partial class Form1 : Form
    {
        private UserParcelView upv;
        //Precondition: None
        //Postcondition: GUI is displayed upon running
        public Form1()
        {
            InitializeComponent();

            upv = new UserParcelView();

            upv.AddAddress("Mason Wuest", "3454 River Rd.",
                "Louisville", "KY", 40242); //Test Address 1
            upv.AddAddress("Allen Orms", "8 New Saddle St.",
                "Severna Park", "MD", 21146); //Test Address 2
            upv.AddAddress("Alex Gudgel", "969 Lexington Rd.",
                "Maplewood", "NJ", 07040); //Test Address 3
            upv.AddAddress("Matt Holston", "97 Cactus St.",
                "Buckeye", "AZ", 85326); //Test Address 4
            upv.AddAddress("Tommy Kushner", "480 Lees Creek Lane",
                "West Hempstead", "KY", 11552); //Test Address 5
            upv.AddAddress("Alex Godfrey", "566 East Lane",
                "Xenia", "OH", 45385); //Test Address 6
            upv.AddAddress("Kelcy Lewis", "918 Beach St.",
                "Rowlett", "TX", 75088); //Test Address 7
            upv.AddAddress("Evan Callahan", "877 Sunset Lane",
                "Clarkston", "MI", 48348); //Test Address 8

            upv.AddGroundPackage(upv.AddressAt(6), upv.AddressAt(7), 5, 10, 20, 20);//Test Ground Packages
            upv.AddGroundPackage(upv.AddressAt(3), upv.AddressAt(4), 10, 15, 20, 25);
            upv.AddGroundPackage(upv.AddressAt(1), upv.AddressAt(2), 7, 9, 10, 25);

            upv.AddLetter(upv.AddressAt(8), upv.AddressAt(1), 4.50m);// Test Letters
            upv.AddLetter(upv.AddressAt(7), upv.AddressAt(2), 4.00m);
            upv.AddLetter(upv.AddressAt(6), upv.AddressAt(3), 2.00m);

            upv.AddNextDayAirPackage(upv.AddressAt(8), upv.AddressAt(5), 9, 8, 7, 25,10.00m);// Test NDAP
            upv.AddNextDayAirPackage(upv.AddressAt(7), upv.AddressAt(2), 7, 9, 10, 20,15.00m);
            upv.AddNextDayAirPackage(upv.AddressAt(6), upv.AddressAt(8), 8, 10, 8, 15,20.00m);

            upv.AddTwoDayAirPackage(upv.AddressAt(5), upv.AddressAt(3), 8, 6, 4, 20,TwoDayAirPackage.Delivery.Early); //Test TDAP
            upv.AddTwoDayAirPackage(upv.AddressAt(8), upv.AddressAt(1), 9, 7, 3, 15, TwoDayAirPackage.Delivery.Saver);
            upv.AddTwoDayAirPackage(upv.AddressAt(7), upv.AddressAt(4), 10, 10, 5, 18, TwoDayAirPackage.Delivery.Early);

        }
        //Precondition: None
        //Postcondition: My information is displayed
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(String.Format("Program 2{0}Grading ID:D7370{0}" +
               "CIS 200-76{0}Fall 2017", System.Environment.NewLine), "Program 2 details:");
        }
        //Precondition: None
        //Postcondition: Application closes
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Precondition: Address Option is selected from GUI
        //Postcondition: Input is stored and populated in UPV
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Prog2Form prog2Form = new Prog2Form(upv.AddressList);
            DialogResult result;
            string names;// holds name
            string ad1;// holds ad1
            string ad2;// holds ad2
            string city;// holds city
            string state;// holds state
            int zip;// holds zip

            result =Prog2Form.ShowDialog();

            if(result == DialogResult.OK)
            {
                
                names = prog2Form.adName;
                ad1 = prog2Form.addressLine1;
                ad2 = prog2Form.addressLine2;
                city = prog2Form.addressCity;
                state = prog2Form.adState;
                zip = int.Parse(prog2Form.adZip);
                upv.AddAddress(names, ad1, ad2, city, state, zip);
            }
        }
        //Precondition: Letter Option is selected from GUI
        //Postcondition: Input is stored and populated in UPV
        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm LetterForm = new LetterForm(upv.AddressList);
            DialogResult result;
            decimal fCost;// holds fixed cost
            int oIndex;// holds index of origin address
            int dIndex;// holds index of destination address

            result = LetterForm.ShowDialog();
            if (result == DialogResult.OK)
            {
                oIndex = LetterForm.oIndex;
                dIndex = LetterForm.dIndex;
                fCost = decimal.Parse(LetterForm.LetterFixedCost);
            }
        }
        //Precondition: None
        //Postcondition: Displays addresses on GUI
        private void listAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disTB.AppendText("Addresses:" + Environment.NewLine + Environment.NewLine);

            //Step through list 
            foreach (Address item in upv.AddressList)
            {
                disTB.AppendText(item.ToString() + Environment.NewLine);
                disTB.AppendText("================================" + Environment.NewLine);
            }

        }
        //Precondition: None
        //Postcondition: Displays list of parcel items
        private void listParcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disTB.AppendText("Parcels:" + Environment.NewLine);

            //Step through list of addresses and display in text box.
            foreach (Parcel item in upv.ParcelList)
            {
                disTB.AppendText(item.ToString() + Environment.NewLine);
                disTB.AppendText("================================" + Environment.NewLine);
            }
        }
    }
}
