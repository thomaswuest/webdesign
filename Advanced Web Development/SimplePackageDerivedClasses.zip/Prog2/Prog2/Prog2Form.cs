﻿// Grading ID:D7370
// CIS 200-76
// October 23,2017
// Program2
// In this specific class we create the functionality for adding addresses to the main form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class Prog2Form : Form
    {
        // Precondition: none
        // Postcondition: The class is formed and the combo box will have the states populated
        public Prog2Form()
        {
            InitializeComponent();
            stateCB.Items.Add("KY");
            stateCB.Items.Add("MD");
            stateCB.Items.Add("NJ");
            stateCB.Items.Add("AZ");
            stateCB.Items.Add("OH");
            stateCB.Items.Add("TX");
            stateCB.Items.Add("MI");
        }
        //Precondition: Name text box must have an input
        //Postcondition: Error Message displayed
        private void nameTB_Valid(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(nameTB.Text))
            {
                e.Cancel = true;
                nameTB.Focus();
                nameErrorProvider.SetError(nameTB, "A name must be entered.");
            }
        }
        //Precondition: None
        //Postcondition: Name is validated
        private void nameTB_Validated(object sender, EventArgs e)
        {
            nameErrorProvider.SetError(nameTB, "");
        }
        //Precondition: Name text box must have an input
        //Postcondition: Error Message displayed
        private void adTB1_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(adTB1.Text))
            {
                e.Cancel = true;
                adTB1.Focus();
                ad1ErrorProvider1.SetError(adTB1, "An Address must be entered.");
            }
        }
        //Precondition: None
        //Postcondition: Address is validated
        private void adTB1_Validated(object sender, EventArgs e)
        {
            ad1ErrorProvider1.SetError(adTB1, "");
        }
        //Precondition: Name text box must have an input
        //Postcondition: Error Message displayed
        private void cityTB_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(cityTB.Text))
            {
                e.Cancel = true;
                cityTB.Focus();
                cityErrorProvider1.SetError(cityTB, "A City must be entered.");
            }
        }
        //Precondition: None
        //Postcondition: City is validated
        private void cityTB_Validated(object sender, EventArgs e)
        {
            cityErrorProvider1.SetError(cityTB, "");
        }
        //Precondition: Name text box must have an input
        //Postcondition:Error Message displayed
        private void stateCB_Validating(object sender, CancelEventArgs e)
        {
            if(stateCB.SelectedIndex <0)
            {
                e.Cancel = true;
                stateCB.Focus();
                stateErrorProvider1.SetError(stateCB, "A state must be selected.");
            }
        }
        //Precondition: None
        //Postcondition: state is validated
        private void stateCB_Validated(object sender, EventArgs e)
        {
            stateErrorProvider1.SetError(stateCB, "");
        }
        //Precondition: Zip text box must have an input
        //Postcondition: Error Message displayed
        private void zipTB_Validating(object sender, CancelEventArgs e)
        {
            int zips; //Variable to hold zip

            if (!int.TryParse(zipTB.Text, out zips))
            {
                e.Cancel = true;
                zipTB.SelectAll();
                zipErrorProvider1.SetError(zipTB, "Please enter a valid integer.");
            }
            else if (zips <= 00000 || zips >= 99999)
            {
                e.Cancel = true;
                zipTB.SelectAll();
                zipErrorProvider1.SetError(zipTB, "Zip must be between 00000 and 99999");
            }

        }
        //Precondition: None
        //Postcondition: Zip is validated
        private void zipTB_Validated(object sender, EventArgs e)
        {
            nameErrorProvider.SetError(zipTB, "");
        }
        //Precondition: None
        //Postcondition: Name is returned/set to the value
        public string adName
        {
            get
            {
                return nameTB.Text;
            }
            set
            {
                nameTB.Text = value;
            }
        }
        ///Precondition: None
        //Postcondition: address is returned/set to the value
        public string addressLine1
        {
            get
            {
                return adTB1.Text;
            }
            set
            {
                adTB1.Text = value;
            }
        }
        ///Precondition: None
        //Postcondition: Address2 is returned/set to the value
        public string addressLine2
        {
            get
            {
                return adTB2.Text;
            }
            set
            {
                adTB2.Text = value;
            }
        }
        ///Precondition: None
        //Postcondition: City is returned/set to the value
        public string addressCity
        {
            get
            {
                return cityTB.Text;
            }
            set
            {
                cityTB.Text = value;
            }
        }
        ///Precondition: None
        //Postcondition: State is returned/set to the value
        internal string adState
        {
            get
            {
                return stateCB.Text;
            }
            set
            {
                stateCB.Text = value;
            }
        }
        ///Precondition: None
        //Postcondition: Zip is returned/set to the value
        public string adZip
        {
            get
            {
                return zipTB.Text;
            }
            set
            {
                zipTB.Text = value;
            }
        }
        //Precondition: None
        //Postcondition: Closes address form
        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
        //Precondition: All inputs passed verification
        //Postcondition: form closes
        private void acceptButton_Click(object sender, EventArgs e)
        {
            if(this.ValidateChildren())
            {
                this.DialogResult = DialogResult.OK;
            }
        }
    }
}
