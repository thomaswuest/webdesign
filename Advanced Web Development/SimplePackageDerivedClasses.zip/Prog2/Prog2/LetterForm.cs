﻿//Grading ID:D7370
// CIS 200-76
// October 23,2017
// Program2
// In this specific class we create the functionality for adding letters to the main form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class LetterForm : Form
    {
        //Precondition: Address list must have data in it
        //Postcondition: Creates the latters and populates the combo boxes

        public LetterForm(List<Address> AddressList)
        {
            InitializeComponent();

            foreach(Address item in AddressList)
            {
                ocb1.Items.Add(item.Name);
                dcb1.Items.Add(item.Name);
            }
        }
        
        private void LetterForm_Load(object sender, EventArgs e)
        {

        }

        //Precondition: none
        //Postcondition: The form will close
        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Precondition: The error provider must be valid(true)
        //Postcondition: The dialog box that is created will close and the letter will populate
        private void okButton_Click(object sender, EventArgs e)
        {
            if(this.ValidateChildren())
            {
                this.DialogResult = DialogResult.OK;
            }
        }
        //Precondition: An origin address must be selected and the oAD and the dAD must be different
        //Postcondition: If it doesnt validate an error message will be created
        private void ocb1_Validating(object sender, CancelEventArgs e)
        {
            if(ocb1.SelectedIndex < 0)
            {
                e.Cancel = true;
                ocb1.Focus();
                oADErrorProvider1.SetError(ocb1, "One must select an origin address.");
            }
            else if(ocb1.SelectedIndex == dcb1.SelectedIndex)
            {
                e.Cancel = true;
                ocb1.Focus();
                oADErrorProvider1.SetError(ocb1, "Origin and Dest address must  be different");
            }
        }
        //Precondition: None
        //Postcondition: Creates the latters and populates the combo boxes
        private void ocb1_Validated(object sender, EventArgs e)
        {
            oADErrorProvider1.SetError(ocb1, "");
        }
        //Precondition: An dest address must be selected and the oAD and the dAD must be different
        //Postcondition: If it doesnt validate an error message will be created
        private void dcb1_Validating(object sender, CancelEventArgs e)
        {
            if(dcb1.SelectedIndex < 0)
            {
                e.Cancel = true;
                dcb1.Focus();
                dADErrorProvider1.SetError(dcb1, "One must select an destination address.");
            }
            else if (ocb1.SelectedIndex == dcb1.SelectedIndex)
            {
                e.Cancel = true;
                dcb1.Focus();
                dADErrorProvider1.SetError(dcb1, "Origin and Dest address must  be different");
            }
        }
        //Precondition: None
        //Postcondition: Creates the latters and populates the combo boxes
        private void dcb1_Validated(object sender, EventArgs e)
        {
            dADErrorProvider1.SetError(dcb1, "");
        }
        //Precondition: An fixed cost must be entered
        //Postcondition: If it doesnt validate an error message will be created
        private void fCostTB_Validating(object sender, CancelEventArgs e)
        {
            decimal cost;

            if (!decimal.TryParse(fCostTB.Text,out cost))
            {
                e.Cancel = true;
                fCostTB.Focus();
                fCostErrorProvider1.SetError(ocb1, "Enter cost in a valid format.");
            }
            else if (cost <=0)
            {
                e.Cancel = true;
                fCostTB.Focus();
                fCostErrorProvider1.SetError(fCostTB, "Cost must be greater than or equal to 0");
            }
        }
        //Precondition:None
        //Postcondition: Creates the latters and populates the cost
        private void fCostTB_Validated(object sender, EventArgs e)
        {
            fCostErrorProvider1.SetError(fCostTB, "");
        }

        ///Precondition: None
        //Postcondition: Origin address is returned/set to the value
        public int OIndex
        {
            get
            {
                return ocb1.SelectedIndex;
            }
            set
            {
                ocb1.SelectedIndex = value;
            }
        }
        ///Precondition: None
        //Postcondition: Destination address is returned/set to the value
        public int DIndex
        {
            get
            {
                return dcb1.SelectedIndex;
            }
            set
            {
                dcb1.SelectedIndex = value;
            }
        }
        ///Precondition: None
        //Postcondition: Fixed Cost is returned/set to the value
        public string LFCost
        {
            get
            {
                return fCostTB.Text;
            }
            set
            {
                fCostTB.Text = value;
            }
        }
    }
    }

