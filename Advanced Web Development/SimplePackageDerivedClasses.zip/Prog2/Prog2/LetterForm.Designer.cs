﻿namespace Prog2
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.originAddressLabel = new System.Windows.Forms.Label();
            this.destAddressLabel = new System.Windows.Forms.Label();
            this.dcb1 = new System.Windows.Forms.ComboBox();
            this.ocb1 = new System.Windows.Forms.ComboBox();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.fCostLabel = new System.Windows.Forms.Label();
            this.fCostTB = new System.Windows.Forms.TextBox();
            this.oADErrorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.dADErrorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.fCostErrorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.oADErrorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dADErrorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fCostErrorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // originAddressLabel
            // 
            this.originAddressLabel.AutoSize = true;
            this.originAddressLabel.Location = new System.Drawing.Point(12, 33);
            this.originAddressLabel.Name = "originAddressLabel";
            this.originAddressLabel.Size = new System.Drawing.Size(106, 17);
            this.originAddressLabel.TabIndex = 0;
            this.originAddressLabel.Text = "Origin Address:";
            // 
            // destAddressLabel
            // 
            this.destAddressLabel.AutoSize = true;
            this.destAddressLabel.Location = new System.Drawing.Point(12, 81);
            this.destAddressLabel.Name = "destAddressLabel";
            this.destAddressLabel.Size = new System.Drawing.Size(139, 17);
            this.destAddressLabel.TabIndex = 1;
            this.destAddressLabel.Text = "Destination Address:";
            // 
            // dcb1
            // 
            this.dcb1.FormattingEnabled = true;
            this.dcb1.Location = new System.Drawing.Point(157, 81);
            this.dcb1.Name = "dcb1";
            this.dcb1.Size = new System.Drawing.Size(342, 24);
            this.dcb1.TabIndex = 2;
            this.dcb1.Validating += new System.ComponentModel.CancelEventHandler(this.dcb1_Validating);
            this.dcb1.Validated += new System.EventHandler(this.dcb1_Validated);
            // 
            // ocb1
            // 
            this.ocb1.FormattingEnabled = true;
            this.ocb1.Location = new System.Drawing.Point(157, 26);
            this.ocb1.Name = "ocb1";
            this.ocb1.Size = new System.Drawing.Size(342, 24);
            this.ocb1.TabIndex = 3;
            this.ocb1.Validating += new System.ComponentModel.CancelEventHandler(this.ocb1_Validating);
            this.ocb1.Validated += new System.EventHandler(this.ocb1_Validated);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(172, 192);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 37);
            this.okButton.TabIndex = 4;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(280, 192);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 37);
            this.cancelButton.TabIndex = 5;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // fCostLabel
            // 
            this.fCostLabel.AutoSize = true;
            this.fCostLabel.Location = new System.Drawing.Point(15, 149);
            this.fCostLabel.Name = "fCostLabel";
            this.fCostLabel.Size = new System.Drawing.Size(77, 17);
            this.fCostLabel.TabIndex = 6;
            this.fCostLabel.Text = "Fixed Cost:";
            // 
            // fCostTB
            // 
            this.fCostTB.Location = new System.Drawing.Point(157, 143);
            this.fCostTB.Name = "fCostTB";
            this.fCostTB.Size = new System.Drawing.Size(342, 22);
            this.fCostTB.TabIndex = 7;
            this.fCostTB.Validating += new System.ComponentModel.CancelEventHandler(this.fCostTB_Validating);
            this.fCostTB.Validated += new System.EventHandler(this.fCostTB_Validated);
            // 
            // oADErrorProvider1
            // 
            this.oADErrorProvider1.ContainerControl = this;
            // 
            // dADErrorProvider1
            // 
            this.dADErrorProvider1.ContainerControl = this;
            // 
            // fCostErrorProvider1
            // 
            this.fCostErrorProvider1.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 264);
            this.Controls.Add(this.fCostTB);
            this.Controls.Add(this.fCostLabel);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.ocb1);
            this.Controls.Add(this.dcb1);
            this.Controls.Add(this.destAddressLabel);
            this.Controls.Add(this.originAddressLabel);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            this.Load += new System.EventHandler(this.LetterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.oADErrorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dADErrorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fCostErrorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originAddressLabel;
        private System.Windows.Forms.Label destAddressLabel;
        private System.Windows.Forms.ComboBox dcb1;
        private System.Windows.Forms.ComboBox ocb1;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Label fCostLabel;
        private System.Windows.Forms.TextBox fCostTB;
        private System.Windows.Forms.ErrorProvider oADErrorProvider1;
        private System.Windows.Forms.ErrorProvider dADErrorProvider1;
        private System.Windows.Forms.ErrorProvider fCostErrorProvider1;
    }
}