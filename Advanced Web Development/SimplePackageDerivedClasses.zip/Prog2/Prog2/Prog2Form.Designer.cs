﻿namespace Prog2
{
    partial class Prog2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.adTB1 = new System.Windows.Forms.TextBox();
            this.adTB2 = new System.Windows.Forms.TextBox();
            this.cityTB = new System.Windows.Forms.TextBox();
            this.zipTB = new System.Windows.Forms.TextBox();
            this.stateCB = new System.Windows.Forms.ComboBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.stateLabel = new System.Windows.Forms.Label();
            this.zipLabel = new System.Windows.Forms.Label();
            this.acceptButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.nameErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.ad1ErrorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.cityErrorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.stateErrorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.zipErrorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nameErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ad1ErrorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityErrorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateErrorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zipErrorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(109, 36);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(130, 22);
            this.nameTB.TabIndex = 0;
            this.nameTB.Validating += new System.ComponentModel.CancelEventHandler(this.nameTB_Valid);
            this.nameTB.Validated += new System.EventHandler(this.nameTB_Validated);
            // 
            // adTB1
            // 
            this.adTB1.Location = new System.Drawing.Point(109, 70);
            this.adTB1.Name = "adTB1";
            this.adTB1.Size = new System.Drawing.Size(130, 22);
            this.adTB1.TabIndex = 1;
            this.adTB1.Validating += new System.ComponentModel.CancelEventHandler(this.adTB1_Validating);
            this.adTB1.Validated += new System.EventHandler(this.adTB1_Validated);
            // 
            // adTB2
            // 
            this.adTB2.Location = new System.Drawing.Point(109, 109);
            this.adTB2.Name = "adTB2";
            this.adTB2.Size = new System.Drawing.Size(130, 22);
            this.adTB2.TabIndex = 2;
            // 
            // cityTB
            // 
            this.cityTB.Location = new System.Drawing.Point(109, 149);
            this.cityTB.Name = "cityTB";
            this.cityTB.Size = new System.Drawing.Size(130, 22);
            this.cityTB.TabIndex = 3;
            this.cityTB.Validating += new System.ComponentModel.CancelEventHandler(this.cityTB_Validating);
            this.cityTB.Validated += new System.EventHandler(this.cityTB_Validated);
            // 
            // zipTB
            // 
            this.zipTB.Location = new System.Drawing.Point(109, 247);
            this.zipTB.Name = "zipTB";
            this.zipTB.Size = new System.Drawing.Size(130, 22);
            this.zipTB.TabIndex = 4;
            this.zipTB.Validating += new System.ComponentModel.CancelEventHandler(this.zipTB_Validating);
            this.zipTB.Validated += new System.EventHandler(this.zipTB_Validated);
            // 
            // stateCB
            // 
            this.stateCB.FormattingEnabled = true;
            this.stateCB.Location = new System.Drawing.Point(109, 205);
            this.stateCB.Name = "stateCB";
            this.stateCB.Size = new System.Drawing.Size(130, 24);
            this.stateCB.TabIndex = 5;
            this.stateCB.Validating += new System.ComponentModel.CancelEventHandler(this.stateCB_Validating);
            this.stateCB.Validated += new System.EventHandler(this.stateCB_Validated);
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(31, 36);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(49, 17);
            this.nameLabel.TabIndex = 6;
            this.nameLabel.Text = "Name:";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(31, 73);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(64, 17);
            this.addressLabel.TabIndex = 7;
            this.addressLabel.Text = "Address:";
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Location = new System.Drawing.Point(31, 152);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(35, 17);
            this.cityLabel.TabIndex = 8;
            this.cityLabel.Text = "City:";
            // 
            // stateLabel
            // 
            this.stateLabel.AutoSize = true;
            this.stateLabel.Location = new System.Drawing.Point(31, 208);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(45, 17);
            this.stateLabel.TabIndex = 9;
            this.stateLabel.Text = "State:";
            // 
            // zipLabel
            // 
            this.zipLabel.AutoSize = true;
            this.zipLabel.Location = new System.Drawing.Point(31, 250);
            this.zipLabel.Name = "zipLabel";
            this.zipLabel.Size = new System.Drawing.Size(32, 17);
            this.zipLabel.TabIndex = 10;
            this.zipLabel.Text = "Zip:";
            // 
            // acceptButton
            // 
            this.acceptButton.Location = new System.Drawing.Point(34, 302);
            this.acceptButton.Name = "acceptButton";
            this.acceptButton.Size = new System.Drawing.Size(81, 40);
            this.acceptButton.TabIndex = 11;
            this.acceptButton.Text = "OK";
            this.acceptButton.UseVisualStyleBackColor = true;
            this.acceptButton.Click += new System.EventHandler(this.acceptButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(171, 302);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 40);
            this.cancelButton.TabIndex = 12;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // nameErrorProvider
            // 
            this.nameErrorProvider.ContainerControl = this;
            // 
            // ad1ErrorProvider1
            // 
            this.ad1ErrorProvider1.ContainerControl = this;
            // 
            // cityErrorProvider1
            // 
            this.cityErrorProvider1.ContainerControl = this;
            // 
            // stateErrorProvider1
            // 
            this.stateErrorProvider1.ContainerControl = this;
            // 
            // zipErrorProvider1
            // 
            this.zipErrorProvider1.ContainerControl = this;
            // 
            // Prog2Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 357);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.acceptButton);
            this.Controls.Add(this.zipLabel);
            this.Controls.Add(this.stateLabel);
            this.Controls.Add(this.cityLabel);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.stateCB);
            this.Controls.Add(this.zipTB);
            this.Controls.Add(this.cityTB);
            this.Controls.Add(this.adTB2);
            this.Controls.Add(this.adTB1);
            this.Controls.Add(this.nameTB);
            this.Name = "Prog2Form";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nameErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ad1ErrorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityErrorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateErrorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zipErrorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.TextBox adTB1;
        private System.Windows.Forms.TextBox adTB2;
        private System.Windows.Forms.TextBox cityTB;
        private System.Windows.Forms.TextBox zipTB;
        private System.Windows.Forms.ComboBox stateCB;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.Label stateLabel;
        private System.Windows.Forms.Label zipLabel;
        private System.Windows.Forms.Button acceptButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ErrorProvider nameErrorProvider;
        private System.Windows.Forms.ErrorProvider ad1ErrorProvider1;
        private System.Windows.Forms.ErrorProvider cityErrorProvider1;
        private System.Windows.Forms.ErrorProvider stateErrorProvider1;
        private System.Windows.Forms.ErrorProvider zipErrorProvider1;
    }
}

