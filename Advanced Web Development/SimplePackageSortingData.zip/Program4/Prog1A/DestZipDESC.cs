﻿// Program 4
// CIS 200-76
// Fall 2017
// Due: 11/27/2017
// By: D7370
//Description: Compares 2 inputs and returns the appropriate values for sorting by DestZip in descending order

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class DestZipDESC :IComparer<Parcel>
    {
        // Precondition:  none
        // Postcondition: when input1 > input2 return a positive #
        //                when input1 < input2 return a negative #
        //                when input1 == input2 return a zero
        public int Compare(Parcel input1, Parcel input2)
        {
            if (input1 == null && input2 == null) // AND statement that compares equal values
                return 0;
            if (input1 == null) // input 1 if
                return -1;
            if (input2 == null)// input 2 if
                return 1;
            return (input2.DestinationAddress.Zip).CompareTo(input1.DestinationAddress.Zip); // compares values and returns the appropriate value(-1,0,1)
        }
    }
}
