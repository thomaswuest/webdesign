﻿// Program 4
// CIS 200-76
// Fall 2017
// Due: 11/27/2017
// By: D7370
//Description: Compares 2 inputs and returns the appropriate values for sorting by Type in ascending order and then descending by cost.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class ASCbyTYPEDESCbyCOST : IComparer<Parcel>

    {
        // Precondition:  none
        // Postcondition: when input1 > input2 return a positive #
        //                when input1 < input2 return a negative #
        //                when input1 == input2 return a zero
        public int Compare(Parcel input1, Parcel input2)
        {
            string type1;// declares string variable type1
            string type2;// declares string variable type2

            if(input1 == null && input2 == null)// AND statement that compares equal values
                return 0;
            if(input1 == null)//Input1 comparison
                return -1;
            if(input2 == null)//input2 comparison
                return 1;

            type1 = input1.GetType().ToString();// Gets Type 1 value based on input 1
            type2 = input2.GetType().ToString();// // Gets Type 2 value based on input 1

            if (type1 == type2)
                return (input1.CalcCost()).CompareTo(input2.CalcCost());// compares values CALCCOST and returns the appropriate value(-1,0,1)


            return type1.CompareTo(type2);
        }
            

    }
}
