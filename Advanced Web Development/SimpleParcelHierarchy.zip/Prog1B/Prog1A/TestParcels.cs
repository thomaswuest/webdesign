﻿// Program 1B
// CIS 200-76
// Fall 2017
// Due: 10/4/2017
// By: B7370

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Emily Shader", "3113 Springstead Circle", "Apt. 9",
                "Louisville", "KY", 40241); // Test Address 5
            Address a6 = new Address("Kelcy Lewis", "9300 Tiverton Way", "Unit 4",
               "Louisville", "KY", 40242); // Test Address 6
            Address a7 = new Address("Matt Holston", "723 Pumpkin Hill Ave.", "Apt. 16",
                "Sulphur", "LA",70663 ); // Test Address 7
            Address a8 = new Address("Allen Orms", "3 Rosewood St.", "Unit 7",
                "Lombard", "IL", 60148); // Test Address 8

            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a2, a1, 4.00M);
            Letter letter3 = new Letter(a3, a4, 4.50M);
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a5, a6, 15, 10, 7, 15);
            GroundPackage gp3 = new GroundPackage(a7, a8, 13, 12, 6, 14);
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a2, a7,30, 12, 17,    
                80, 8.50M);
            NextDayAirPackage ndap3 = new NextDayAirPackage(a8, a4, 20, 20, 14,    
                85, 9.30M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a7, a1, 49.5, 37.5, 24.0, 
                78.4, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a8, a3, 43.5, 38.5, 27.0, 
                90.0, TwoDayAirPackage.Delivery.Saver);



            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populates list
            parcels.Add(letter2);
            parcels.Add(letter3);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(gp3);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);
           
            // Column header/seperator for data
            Console.WriteLine("Original List:");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine("====================");
            }
            Pause();

            // Column header/seperator for data
            Console.WriteLine("Order by Destination Zip (Descending):");
            Console.WriteLine("====================");
            // Holds results of LINQ to sort invoices by zip code
            var sZipDesc =
                from parcel in parcels
                orderby parcel.DestinationAddress.Zip descending
                select parcel;

            foreach (Parcel parcel in sZipDesc)
            {
                Console.WriteLine(parcel);
                Console.WriteLine("====================");
            }
            Pause();

            // Column header/seperator for data
            Console.WriteLine("Order by Cost (Ascending):");
            Console.WriteLine("====================");
            // Holds results of LINQ to  sort by cost
            var sCostAsc =
                from parcel in parcels
                orderby parcel.CalcCost() ascending
                select parcel;
            foreach (Parcel parcel in sCostAsc)
            {
                Console.WriteLine(parcel);
                Console.WriteLine("====================");
            }
            Pause();
            // Holds results of LINQ to select parcel type and then sort by cost
            var sParcelCost =
                from parcel in parcels
                orderby parcel.GetType() ascending
                select parcel;

            // Column header/seperator for data
            Console.WriteLine("Order by Parcel Type and cost:");
            Console.WriteLine("====================");
            foreach (var parcel in sParcelCost)
            {
                Console.WriteLine(parcel);
                Console.WriteLine("====================");
            }
            Pause();

            // Holds results of LINQ to select Heavy Packages and sort by weight
            var sHeavyWeight =
                from parcel in parcels
                let i = parcel as AirPackage
                where (i != null) && i.IsHeavy()
                orderby i.Weight ascending
                select parcel;
            // Column header/seperator for data
            Console.WriteLine("AirPackage Objects that are Heavy and ordered by Weight");
            Console.WriteLine("======================================================");
            foreach(Parcel parcel in sHeavyWeight)
            {
                Console.WriteLine(parcel);
                Console.WriteLine("====================");
                
            }

        }
        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
