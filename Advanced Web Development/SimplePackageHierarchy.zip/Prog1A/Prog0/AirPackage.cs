﻿// Program 1A
// CIS 200-76
// Fall 2017
// Due: 9/25/2017
// By: B7370
// This program allows us to practice the specific hierarchy need for this delivery system.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class AirPackage : Package
{
    public const double HEAVY_PACKAGE = 75; // Minimum weight of a heavy package
    public const double LARGE_PACKAGE = 100; //  Minimum dimensions of a large package

    // Precondition: Length >= 0, Width >= 0, Height >=0, Weight >= 0
    // Postcondition: The two day air package is created with the specified values for 
    // origin address, destination address, length, width, height, weight, and delivery type 
    public AirPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight)
         : base(originAddress, destAddress, length, width, height, weight)
    {

    }
    // Precondition: None 
    // Postcondition: Returns true if considered heavy else returns false
    public bool IsHeavy()
    {
        return (Weight >= HEAVY_PACKAGE);
    }
    // Precondition: None 
    // Postcondition: Returns true if considered large else returns false
    public bool IsLarge()
    {
        return (Length + Width + Height >= LARGE_PACKAGE);
    }
    // Precondition: None 
    // Postcondition: A String with the air package data will be returned
    public override String ToString()
    {
        
        return String.Format("Air Package IsHeavy: Air Package IsLarge:", base.ToString(), IsHeavy(), IsLarge(), System.Environment.NewLine);
    }
}