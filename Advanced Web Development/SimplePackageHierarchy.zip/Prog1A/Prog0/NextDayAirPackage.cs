﻿// Program 1A
// CIS 200-76
// Fall 2017
// Due: 9/25/2017
// By: B7370
// This program allows us to practice the specific hierarchy need for this delivery system.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class NextDayAirPackage : AirPackage
    {
        private decimal _exsFee;

        // Precondition: Length >= 0, Width >= 0, Height >=0, Weight >= 0, exsFee >=0 
        // Postcondition: The next day air package is created with the specified values for  origin address, destination address, length, width, height, weight, and express fe
        public NextDayAirPackage(Address originAddress,Address destAddress, double length, double width, double height, double weight,
            decimal expresssFee) : base(originAddress,destAddress, length,width,height,weight)
        {
            ExpressFee = expresssFee;
        }

        public decimal ExpressFee
        {// Precondition: None 
         // Postcondition: The next day express fee has been returned
            get
            {
                return _exsFee;
            }
            // Precondition: value >= 0 
            // Postcondition: The next day air package's express fee will be set to the specified value
            private set
            {
                if (value >= 0)
                    _exsFee = value;
                else
                    throw new ArgumentOutOfRangeException("Express Shipping Fee", value, "Fee must be positive");
            }
        }
        // Precondition: None 
        // Postcondition: The next day air package's cost will be returned
        public override decimal CalcCost()
        {
            decimal baseCost = .40m * ((decimal)Length + (decimal)Width + (decimal)Height) + .30m * ((decimal)Weight);
            decimal weightCharge = .25m * ((decimal)Weight);
            decimal sizeCharge = .25m * ((decimal)Length + (decimal)Width + (decimal)Height);
            if (IsHeavy())
                return baseCost += weightCharge;
            else if (IsLarge())
                return baseCost += sizeCharge;
            else
                return baseCost;
        }
        // Precondition: None 
        // Postcondition: A String with the next day air package's data has been returned
        public override string ToString()
        {
            string NL = Environment.NewLine;

            return $"{NL}{base.ToString()}{ExpressFee}{CalcCost()}{NL}";
        }

    }
}
