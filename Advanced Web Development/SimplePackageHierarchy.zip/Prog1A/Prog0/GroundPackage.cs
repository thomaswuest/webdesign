﻿// Program 1A
// CIS 200-76
// Fall 2017
// Due: 9/25/2017
// By: B7370
// This program allows us to practice the specific hierarchy need for this delivery system.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class GroundPackage : Package
    {
        // Precondition: Length >= 0, Width >= 0, Height >=0, Weight >= 0
        // Postcondition: The two day air package is created with the specified values for 
        // origin address, destination address, length, width, height, weight, and delivery type 
        public GroundPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight) : base(originAddress,destAddress, length,width,height,weight)
        {
            
        }
        // Precondition: None 
        // Postcondition: The ground package's zone distance is returned.  
        public int ZoneDistance()
        {
        int distance;
        const int ZIP_CONST = 10000;
            distance = (OriginAddress.Zip / ZIP_CONST) - (DestinationAddress.Zip / ZIP_CONST);
            return Math.Abs(distance);
        
           
        }
        // Precondition: None 
        // Postcondition: The ground package cost will be returned
        public override decimal CalcCost()
        {
            decimal shipCost = .20m*((decimal)Length + (decimal)Width + (decimal)Height) + .05m*((ZoneDistance() + 1) * (decimal)Weight);
            return shipCost;

        }
        // Precondition: None 
        // Postcondition: A String with the ground package's data will be returned
        public override string ToString()
        {
          return String.Format("Ground{0}{3}Zone Distance: {1:D}{3}Cost: {2:C}", base.ToString(), ZoneDistance(), CalcCost(), System.Environment.NewLine);
        }
    }
}
