﻿// Program 1A
// CIS 200-76
// Fall 2017
// Due: 9/25/2017
// By: B7370
// This program allows us to practice the specific hierarchy need for this delivery system.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0

{
    public enum delivery { EARLY, SAVER };
    class TwoDayAirPackage : AirPackage
    {
        

        public delivery Type
        {
            get;
            set;
        }

        // Precondition: Length >= 0, Width >= 0, Height >=0, Weight >= 0
        // Postcondition: The two day air package is created with the specified values for 
        // origin address, destination address, length, width, height, weight, and delivery type 
        public TwoDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight, delivery type
            ) : base(originAddress, destAddress, length, width, height, weight)
        {
        }
        // Precondition: None 
        // Postcondition: The two day air package's cost has been returned
        public override decimal CalcCost()
        {
            const decimal FORM_F = .25m;
            decimal basecost;

            basecost = (FORM_F * ((decimal)Length + (decimal)Width + (decimal)Height)) + FORM_F * ((decimal)Weight);

            return
                basecost;


        }
        // Precondition: None 
        // Postcondition: A String with the two day air package's data has been returned
        public override string ToString()
        {
            return string.Format("TwoDay{0}{3}Delivery Type: {1}{3}Cost:  {2:C}",base.ToString(),
                Type,CalcCost(),System.Environment.NewLine);
        }



    }
}
