﻿// Program 1A
// CIS 200-76
// Fall 2017
// Due: 9/25/2017
// By: B7370
// This program allows us to practice the specific hierarchy need for this delivery system.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class Package : Parcel
{
    private double length; // length of package in inches
    private double width; // width of package in inches
    private double height; // height of package in inches
    private double weight; // weight of package in inches

    // Precondition: Length >= 0, Width >= 0, Height >=0, Weight >= 0
    // Postcondition: The two day air package is created with the specified values for 
    // origin address, destination address, length, width, height, weight, and delivery type 
    public Package(Address originAddress,Address destAddress, double length,double width, double height, double weight)
        : base(originAddress, destAddress)
    {
        
        Length = length;
        Width = width;
        Height = height;
        Weight = weight;
    }
    // Precondition: none
    // Postcondition: The packages length has been returned 
    public double Length
    {
        get
        { return length; }
        set
        {// Precondition: value >= 0 
         // Postcondition: The package's length has been set to the entered value
            if (value >= 0)
                length = value;
            else
                throw new ArgumentOutOfRangeException("Length:", value, "Length must be positive");
        }
        
    }
    // Precondition: none
    // Postcondition: The packages width has been returned 
    public double Width
    {
        get
        { return width; }
        set
        { // Precondition: value >= 0 
          // Postcondition: The package's width has been set to the entered value
            if (value >= 0)
                width = value;
            else
                throw new ArgumentOutOfRangeException("Width:", value, "Width must be positive");
        }

    }
    // Precondition: none
    // Postcondition: The packages height has been returned 
    public double Height
    {
        get
        { return height; }
        set
        {// Precondition: value >= 0 
         // Postcondition: The package's height has been set to the entered value
            if (value >= 0)
                height = value;
            else
                throw new ArgumentOutOfRangeException("Height:", value, "Height must be positive");
        }

    }
    // Precondition: none
    // Postcondition: The packages weight has been returned 
    public double Weight
    {
        get
        { return weight; }
        set
        {// Precondition: value >= 0 
         // Postcondition: The package's weight has been set to the entered value
            if (value >= 0)
                weight= value;
            else
                throw new ArgumentOutOfRangeException("Weight", value, "Weight must be positive");
        }

    }
    // Precondition: None 
    // Postcondition: A String with the package info will be returned
    public override String ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut

        return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}" +
            $"{DestinationAddress}{NL}Length:{Length}{NL}Width:{Width}{NL}Height:{Height}" +
            $"{NL}Weight:{Weight}";
    }
}

