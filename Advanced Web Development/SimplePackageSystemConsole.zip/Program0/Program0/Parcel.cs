﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{   // Creation of abstract class named Parcel
    public abstract class Parcel
    {   // Declaration of the backing fields referencing Address Class
        public Address _originAddress;
        public Address _destinationAddress;

        // Constructor
        // Precondition:  The data is not composed of empty/whitespace
        //                
        // Postcondition: A origin address and destination address has been constructed.
        public Parcel(Address originAddress, Address destinationAddress)
        {
            OriginAddress = originAddress;
            DestAddress = destinationAddress;
        }
        // Get/Set for Origin Address
        public Address OriginAddress
        {   // // Precondition: None
            // Postcondition: The origin address will be returned
            get
            {
                return _originAddress;
            }
            // // Precondition: Checks for null or white space
            // Postcondition: The origin address will be assigned to the value
            set
            {
                _originAddress = value;
            }
        }
        // Get/Set for Destination Address
        public Address DestAddress
        {   // // Precondition: None
            // Postcondition: The dest address will be returned
            get
            {
                return _destinationAddress ;
            }
            // // Precondition: Checks for null or white space
            // Postcondition: Thedest address will be assigned to the value
            set
            {
                _destinationAddress = value;
            }
        }

        
        // Precondition: Check for null or whitespace
        // Postcondition: The method will be  abstract decimal
        public abstract decimal CalcCost();

        

        


    }
}


