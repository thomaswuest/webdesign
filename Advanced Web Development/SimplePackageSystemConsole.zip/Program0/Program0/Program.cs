﻿// Grading ID: D7370
// Program 0
// CIS 200-76
// Due 9/11/2017
// Description: This Program serves as a simple console application to display a package system
// for future package shipping. This allows for multiple classes to integrate into one and display origin/destination addresses. All addresses and
// costs are hardcoded and new methods will be added in a future program.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    class Program
    {
        static void Main()
        {   // Declaration of address and letter data(all hardcoded for now)
            var Address1 = new Address("Mason Wuest", "3113 Springstead Circle","Unit 9", "Louisville", "KY", 40241);
            var Address2 = new Address("Allen Orms","123 6th Street","Apt. 7","Melbourne","FL",32904);
            var Address3 = new Address("Tommy Kushner", "444 Davies Avenue","Unit 15", "Louisville","KY", 40208);
            var Address4 = new Address("Matt Holston", "514 S. Magnolia Street","Apt. 8", "Orlando", "FL", 32806);
            var Letter1 = new Letter(Address1,Address2,9);
            var Letter2 = new Letter(Address3,Address4,11);
            var Letter3 = new Letter(Address2,Address3,9);

            
            // Creation of a new list including the Letter objects created
            var letters = new List<Letter>() { Letter1,Letter2,Letter3 };
            // Writing a header to the console
            Console.WriteLine("Letters being processed for shipping:\n");
            
            //For each loop to step through the list and write the data 
            //to the console using the parcel and letter formatting.
            foreach(var currentLetter in letters)
            {
                Console.WriteLine(currentLetter);
                if(currentLetter is Letter )
                {
                    var address = (Letter)currentLetter;
                  
                }
                
            }
            
        }
    }
}
