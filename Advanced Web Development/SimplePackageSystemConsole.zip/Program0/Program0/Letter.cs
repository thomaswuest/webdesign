﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    class Letter: Parcel
    {   // Declaration of fixed cost backing field
        decimal _fcost;

        // Constructor
        // Precondition:  The data is not composed of empty/whitespace
        //                
        // Postcondition: A origin address, destination address and fixed cost have been constructed.
        public Letter(Address originAddress, Address destinationAddress, decimal fixedCost) : base(originAddress, destinationAddress)
        {
           FixedCost = fixedCost;
        }

        
        private decimal FixedCost
        {   // Precondition:  None
            // Postcondition: The fixed cost has been returned
            get { return _fcost; }
            // Precondition:  None
            // Postcondition: The fixed cost has been returned the value
            set { _fcost = value; }
        }

        // Precondition: None
        // Postcondition: The fixed cost will be returned
        public override decimal CalcCost()
        {
            return FixedCost;
        }

        // Precondition: Check for null or whitespace
        // Postcondition: The string will be formatted to the console
        public override string ToString() =>
        "*New Letter*"+System.Environment.NewLine+System.Environment.NewLine+"Origin Address: " + System.Environment.NewLine + System.Environment.NewLine+ OriginAddress + System.Environment.NewLine + "Destination Address: " +System.Environment.NewLine+ DestAddress + System.Environment.NewLine + "Cost to Ship: " + CalcCost().ToString("c2") + System.Environment.NewLine;
    }
}
