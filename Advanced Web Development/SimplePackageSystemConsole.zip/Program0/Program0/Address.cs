﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    // declaration of public class Adress
    public class Address
    {   // private backing fields for sensitive data
        private string _name;
        private string _address1;
        private string _address2;
        private string _city;
        private string _state;
        private int _zip;


        // Constructor
        // Precondition:  The data is not composed of empty/whitespace
        //                
        // Postcondition: A Name,address,city, state, and zip has been constructed.
        public Address(string name, string address1, string address2, string city, string state, int zip)
        {
            Name = name;
            Ad1 = address1;
            Ad2 = address2;
            City = city;
            State = state;
            Zip = zip;

        }
        // // Precondition: None
        // Postcondition: The name will be returned
        public string Name
        {
            get
            {
                return _name;
            }
            // Precondition: Check for null or whitespace
            // Postcondition: The name will be assigned to the value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Name)} must have a value");
                }
                _name = value;
            }
        }
        // Get/Set for Address including validation
        // // Precondition: None
        // Postcondition: The  address will be returned
        public string Ad1
        {
            get
            {
                return _address1;
            }
            // Precondition: Check for null or whitespace
            // Postcondition: The address will be assigned to the value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Ad1)} must have a value");
                }
                _address1 = value;
            }
        }
        // Get/Set for Address 2 including validation
        public string Ad2
        {   // // Precondition: None
            // Postcondition: The second address will be returned
            get
            {
                return _address2;
            }
            // Precondition: Check for null or whitespace
            // Postcondition: The address 2 will be assigned to the value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Ad2)} must have a value");
                }
                _address2 = value;
            }
        }
        // Get/Set for City including validation
        public string City
        {   // // Precondition: None
            // Postcondition: The city will be returned
            get
            {
                return _city;
            }
            // Precondition: Check for null or whitespace
            // Postcondition: The city will be assigned to the value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(City)} must have a value");
                }
                _city = value;
            }
        }
        // Get/Set for State including validation
        public string State
        {   // // Precondition: None
            // Postcondition: The state will be returned
            get
            {
                return _state;
            }
            // Precondition: Check for null or whitespace
            // Postcondition: The statw will be assigned to the value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(State)} must have a value");
                }
                _state = value;
            }
        }
        // Get/Set for Zip Code including validation
        public int Zip
        {  // // Precondition: None
           // Postcondition: The zip will be returned
            get
            {
                return _zip;
            }
            // Precondition: Check for null or whitespace validate number is in range
            // Postcondition: The zip will be assigned to the value
            set
            {
                if (value < 0 || value > 99999)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Zip)} must have a value between 0-99999");
                }
                _zip = value;
            }
        }
        // To string method for all variables, with formatted zip code
        // Precondition: Check for null or whitespace
        // Postcondition: The string will be formatted
        public override string ToString() =>
            $"Name: {Name}" + System.Environment.NewLine + $"Address: " + System.Environment.NewLine+$"{Ad1}"+System.Environment.NewLine + $"{Ad2}"+ System.Environment.NewLine + $"{City},{State} {Zip:D5}"+System.Environment.NewLine;        
           

    }
}
